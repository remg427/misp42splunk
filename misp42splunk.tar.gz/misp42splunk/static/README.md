# misp42splunk icons and logo 

misp42splunk icons and logo are adapted from MISP logos and licensed under [CC-BY](https://creativecommons.org/licenses/by/4.0/).

[MISP](https://github.com/MISP/MISP) logos are licensed under [CC-BY](https://creativecommons.org/licenses/by/4.0/).

If you have question related to MISP logos, don't hesitate to contact the maintainers of the MISP project
