[proxy]
proxy_enabled = 
proxy_hostname = 
proxy_password = 
proxy_port = 
proxy_username = 

[global_settings]
enable_limit_logging = 
max_execution_time_sec = 
max_response_size_mb = 
progress_log_interval = 

[logging]
loglevel = 
